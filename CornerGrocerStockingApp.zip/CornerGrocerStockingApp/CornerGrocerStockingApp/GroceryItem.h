#include <string>
#ifndef GroceryItem_h
#define GroceryItem_h

class GroceryItem
{
public:
	std::string GetItemName() const;
	int GetFrequency() const;
	void setFrequency(int const frequency);
	GroceryItem();
	GroceryItem(std::string name, int frequency);

private:
	std::string itemName;
	int itemFrequency;

};

#endif

