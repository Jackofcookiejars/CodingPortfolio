#include "GroceryItem.h"

//The two getters for the private data.
std::string GroceryItem::GetItemName() const
{
	return itemName;
}
int GroceryItem::GetFrequency() const
{
	return itemFrequency;
}

//The only setter I should need.
void GroceryItem::setFrequency(int const frequency)
{
	itemFrequency = frequency;
}

GroceryItem::GroceryItem()
{
	itemName = "";
	itemFrequency = 0;
}

//Constructor to not have to dump extra get/set instructions.
GroceryItem::GroceryItem(std::string name, int frequency)
{
	itemName = name;
	itemFrequency = frequency;
}
