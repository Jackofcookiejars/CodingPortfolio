#include <iostream>
#include <iomanip>	
#include <fstream>
#include <vector>
#include "GroceryItem.h"

using namespace std;
//Coded by Zayne Harthun, 2/23/2024

/* Planning:
*  Generate a vector of GroceryItem via loading.
*  While loop, as the user has options to pick.
*  Call user input to determine which option gets picked.
*  IF search, use a for loop to find which GroceryItem shares a name with UI
*  IF Freq, use a for loop to print.
*  IF Hist, use a nested for loop to both print
*/

//These are the user's interface.
void DisplayMenu()
{
	cout << left << setw(40) << setfill('*') << "*" << endl;
	cout << setw(39) << setfill(' ') << "* 1- Search the frequency list" << "*" << endl;
	cout << setw(39) << setfill(' ') << "* 2- Print a fequency count" << "*" << endl;
	cout << setw(39) << setfill(' ') << "* 3- Print a histogram" << "*" << endl;
	cout << setw(39) << setfill(' ') << "* 4- Exit program" << "*" << endl;
	cout << setw(40) << setfill('*') << "*" << right << endl;
}
//This uses a user input to search down the list, when it finds the right item, it outputs item + " " + frequency.
void SearchItem(vector<GroceryItem>& const list)
{
	//Declare input var.
	string input;

	//Prompt User input.
	cout << "Please type the item you're looking for." << endl;
	cin >> input;

	//Loop through list looking for user input.
	for (unsigned int a = 0; a < list.size(); a++)
	{
		if (input == list.at(a).GetItemName())
		{
			cout << input << " " << list.at(a).GetFrequency() << endl;
		}
	}
	cout << endl << endl;
}
//This just prints the whole list.
void PrintFrequencyCount(vector<GroceryItem>& const list)
{
	for (unsigned int a = 0; a < list.size(); a++)
	{
		cout << list.at(a).GetItemName() << " " << list.at(a).GetFrequency() << endl;
	}
	cout << endl << endl;
}
//This nested loop prints the whole list, and a number of stars after that.
void PrintHistogram(vector<GroceryItem>& const list)
{
	for (unsigned int a = 0; a < list.size(); a++)
	{
		cout << left << setw(10) << setfill(' ') << list.at(a).GetItemName();
		for (int b = 0; b < list.at(a).GetFrequency(); b++)
		{
			cout << "*";
		}
		cout << endl;
	}
	cout << endl << endl;
}

//This goes through the whole list and asks if an item exists in it.
//If yes, add +1 to item, else make new GroceryItem with that item's name and a frequency of 1.
void IncrementList(vector<GroceryItem>& list, string input)
{
	for (unsigned int a = 0; a < list.size(); a++)
	{
		if (input == list.at(a).GetItemName())
		{
			list.at(a).setFrequency(list.at(a).GetFrequency() + 1);
			return;
		}
	}
	list.push_back(GroceryItem(input, 1));
}



int main()
{
	//Declare vars for file loading.
	ifstream inputFile;
	vector<GroceryItem> frequencyList(0);

	//Open and ensure file is opened for reading.
	inputFile.open("CS210_Project_Three_Input_File.txt");

	if (!inputFile.is_open())
	{
		cout << "Failed to open input file.";
		return 1;
	}

	//Run a while loop to read the whole file.
	while (!inputFile.fail())
	{
		string temp;
		//Input the name of the item.
		inputFile >> temp;
		//Make sure we aren't putting the end of file bit into our list.
		if (temp != "")
		{
			IncrementList(frequencyList, temp);
		}
	}
	//Close input.
	inputFile.close();

	//Declare output file
	ofstream outputFile;
	//Open and ensure file is open for outputting.
	outputFile.open("frequency.dat");
	if (!outputFile.is_open())
	{
		cout << "Failed to open output file.";
		return 2;
	}
	//Now we output the stuff into the file. This is why I'm using a vector instead of a map.
	for (int a = 0; a < frequencyList.size(); a++)
	{
		outputFile << frequencyList.at(a).GetItemName() << " " << frequencyList.at(a).GetFrequency() << endl;
	}
	//Close output.
	outputFile.close();

	//Declare variales for menu loop.
	bool runState = true;
	int input = 4;

	while (runState)
	{
		DisplayMenu();

		//Try/catch to prevent crashing the whole program if someone decides to get funny and type apple.
		try
		{
			cin >> input;
		}
		catch (...)
		{
			//Set the input to a default value, clear error flag, then skip line.
			input = 0;
			cin.clear();
			cin.ignore(1000, '\n');

		}

		//Switch to determine which menu setting was chosen.
		switch (input)
		{
		case(1):
			SearchItem(frequencyList);
			break;
		case(2):
			PrintFrequencyCount(frequencyList);
			break;
		case(3):
			PrintHistogram(frequencyList);
			break;
		case(4):
			//This falls through for simplicity's sake.
			runState = false;
		default:
			break;
		}

	}





	return 0;
}