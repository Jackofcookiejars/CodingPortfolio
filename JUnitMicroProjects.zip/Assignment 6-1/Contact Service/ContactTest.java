package contactService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;

public class ContactTest {
	
	@Test
	public void ContactConstructorTest()
	{
		//Now we test the Contact methods.		
		Contact temp = new Contact();
		assertTrue(temp.getID() != null);
		assertTrue(temp.getFirstName() != null);
		assertTrue(temp.getLastName() != null);
		assertTrue(temp.getNumber() != null);
		assertTrue(temp.getAddress() != null);
		
		//test set null checks.
		temp.setFirstName(null);
		temp.setLastName(null);
		temp.setNumber(null);
		temp.setAddress(null);
		assertTrue(temp.getFirstName() != null);
		assertTrue(temp.getLastName() != null);
		assertTrue(temp.getNumber() != null);
		assertTrue(temp.getAddress() != null);
		
		//test set size checks.
		temp.setFirstName("12345678901");
		temp.setLastName("12345678901");
		temp.setNumber("12345678901");
		temp.setAddress("This statement is 31 characters");
		assertTrue(temp.getFirstName().length() < 11);
		assertTrue(temp.getLastName().length() < 11);
		assertTrue(temp.getNumber().length() < 11);
		assertTrue(temp.getAddress().length() < 31);
		
		//Test number digit lock.
		temp.setNumber("abc4567890");
		assertTrue(!temp.getNumber().equals("abc4567890"));
		
		
		//test valid sets.
		temp.setFirstName("John");
		assertTrue(temp.getFirstName().equals("John"));
		temp.setLastName("Doe");
		assertTrue(temp.getLastName().equals("Doe"));
		temp.setNumber("1234567890");
		assertTrue(temp.getNumber().equals("1234567890"));
		temp.setAddress("filler");
		assertTrue(temp.getAddress().equals("filler"));
	}

}
