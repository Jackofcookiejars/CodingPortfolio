package contactService;

import java.util.HashMap;
import java.util.Map;

public class ContactService
{
	Map<String, Contact> hold = new HashMap<>();
	
	public Contact add(String id, String firstName, String lastName, String number, String address)
	{
		if(id != null)
		{
			//This limits id length to 10.
			if(id.length() > 10)
			{
				id = id.substring(0,10);
			}
			//Checks to see if ID is unique.
			if (!hold.containsKey(id))
			{
				hold.put(id, new Contact(id, firstName, lastName, number, address));
			}
			else
			{
				System.out.println("Id found, returning known contact");
			}
			return hold.get(id);
		}
		else
			return new Contact();
	}
	
	public Contact delete(String id)
	{
		return hold.remove(id);
	}
	
	public void updateAll(String id, String firstName, String lastName, String number, String address)
	{
		Contact temp = hold.get(id);
		temp.setFirstName(firstName);
		temp.setLastName(lastName);
		temp.setNumber(number);
		temp.setAddress(address);
	}
	public void updateName(String id, String firstName, String lastName)
	{
		Contact temp = hold.get(id);
		temp.setFirstName(firstName);
		temp.setLastName(lastName);
	}
	public void updateNumber(String id, String number)
	{
		Contact temp = hold.get(id);
		temp.setNumber(number);
	}
}
