package contactService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;

public class ContactServiceTest {

	@Test
	public void ContactServiceOperationalTest()
	{
		ContactService test = new ContactService();
		
		//Check to see if the nullID response works
		assertTrue(test.add(null, null, null, null, null).getID() == new Contact().getID());
		
		//Check to see if the system works as intended.
		test.add("ValidTest", "Jenny", "Jenny", "0008675309", " by Tommy Tutone.");
		assertTrue(test.add("ValidTest", null, null, null, null).getFirstName().equals("Jenny"));
		assertTrue(test.add("ValidTest", null, null, null, null).getLastName().equals("Jenny"));
		assertTrue(test.add("ValidTest", null, null, null, null).getNumber().equals("0008675309"));
		assertTrue(test.add("ValidTest", null, null, null, null).getAddress().equals(" by Tommy Tutone."));
		
		//Now to check to see if delete works.
		assertTrue(test.delete("ValidTest").getFirstName().equals("Jenny"));
		assertTrue(!test.add("ValidTest", "John", "Doe", "0123456789", "").getFirstName().equals("Jenny"));
		

	}

}
