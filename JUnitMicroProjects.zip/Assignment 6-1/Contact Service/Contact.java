package contactService;

public class Contact
{
	private String fName, lName, num, add, identity;
	
	public Contact()
	{
		identity = "error";
		fName = lName = num = add = "empty";
	}
	public Contact(String id, String firstName, String lastName, String number, String address)
	{
		//These if statements ensure that the following are true:
		//No variable input is null
		//Number is exactly 10 digits long.
		//No variable input is longer than 10 digits
		//Except for address, which cannot be longer than 30.
		if(id == null)
		{
			identity = "error";
		}
		else if(id.length() > 10)
		{
			identity = id.substring(0,10);
		}
		else
		{
			identity = id;
		}
		if(firstName == null)
		{
			fName = "empty";
		}
		else if(firstName.length() > 10)
		{
			fName = firstName.substring(0, 10);
		}
		else 
		{
			fName = firstName;
		}
		if(lastName == null)
		{
			lName = "empty";
		}
		else if (lastName.length() > 10)
		{
			lName = lastName.substring(0, 10);
		}
		else
		{
			lName = lastName;
		}
		if(number == null)
		{
			num = "0000000000";
		}
		else if (number.length() != 10 || !number.matches("[0-9]{10}"))
		{
			num = "0000000000";
		}
		else
		{
			num = number;
		}
		if(address == null)
		{
			add = "empty";
		}
		else if (address.length() > 30)
		{
			add = address.substring(0,30);
		}
		else
		{
			add = address;
		}
	}
	
	public String getFirstName()
	{
		return fName;
	}
	public String getLastName()
	{
		return lName;
	}
	public String getNumber()
	{
		return num;
	}
	public String getAddress()
	{
		return add;
	}
	public String getID()
	{
		return identity;
	}

	public void setFirstName(String firstName)
	{
		if(firstName != null)
		{
			if (firstName.length() > 10)
			{
				fName = firstName.substring(0, 10);
			}
			else
			{
				fName = firstName;
			}
		}
	}
	public void setLastName(String lastName)
	{
		if(lastName != null)
		{
			if (lastName.length() > 10)
			{
				lName = lastName.substring(0, 10);
			}
			else
			{
				lName = lastName;
			}
		}
	}
	public void setNumber(String number)
	{
		if(number != null)
		{
			if(number.length() == 10)
			{
				if (number.matches("[0-9]{10}"))
				{
					num = number;
				}
			}
		}
	}
	public void setAddress(String address)
	{
		if(address != null)
		{
			if (address.length() > 30)
			{
				add = address.substring(0,30);
			}
			else
			{
				add = address;
			}
		}
	}

	public String toString()
	{
		return identity + ": " + fName + " " +
				lName + " " + num + " " + add;
	}
}
