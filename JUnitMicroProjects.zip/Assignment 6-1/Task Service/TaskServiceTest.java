package taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;


public class TaskServiceTest {
	@Test
	public void TaskServiceOperationTest()
	{		
		//Now we test to see if the Service works as advertised.
		TaskService test = new TaskService();
		
		//Testing add.
		assertTrue(test.add("test", "Mr. Torgue", "flexington").GetID().equals("test"));
		assertTrue(test.add("test",null,null).GetName().equals("Mr. Torgue"));
		assertTrue(test.add("test",null,null).GetDescription().equals("flexington"));
		
		//Testing updateAll
		test.updateAll("test", "Ayn", "Rand");
		assertTrue(test.add("test",null,null).GetName().equals("Ayn"));
		assertTrue(test.add("test",null,null).GetDescription().equals("Rand"));
		
		//Testing updateName
		test.updateName("test", "This is");
		assertTrue(test.add("test", null, null).GetName().equals("This is"));
		
		//Testing updateDesc
		test.updateDesc("test", "Sparta");
		assertTrue(test.add("test", null, null).GetDescription().equals("Sparta"));
		
		//Testing delete
		test.delete("test");
		assertTrue(test.add("test", "John", "Doomguy").GetName().equals("John"));		
	}

}
