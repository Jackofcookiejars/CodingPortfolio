package taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;


public class TaskTest
{
	@Test
	public void TaskVariableTest()
	{
		//First, let's test to see if Task properly accepts the inputs.
		Task test = new Task("test","name","lorem ipsum");
		assertTrue(test.GetID().equals("test"));
		assertTrue(test.GetName().equals("name"));
		assertTrue(test.GetDescription().equals("lorem ipsum"));
		
		//Secondly, let's check to see if the null replacements work.
		test = new Task(null,null,null);
		assertTrue(test.GetID()!=null);
		assertTrue(test.GetName()!=null);
		assertTrue(test.GetDescription()!=null);
		
		//Now let's check to see if the Task properly limits the inputs.
		test = new Task("01234567890", "012345678901234567890", "This field should have 50 characters, that's okay...");
		assertTrue(test.GetID().length()<11);
		assertTrue(test.GetName().length()<21);
		assertTrue(test.GetDescription().length()<51);
		
		//Finally, we test the setters functions.
		test.SetDescription("This field should have 50 characters, that's okay...");
		assertTrue(test.GetDescription().length()<51);
		test.SetName("John Johnsonn the first");
		assertTrue(test.GetName().length()<21);
	}

}
