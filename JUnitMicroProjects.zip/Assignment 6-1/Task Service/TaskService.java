package taskService;

import java.util.HashMap;
import java.util.Map;

public class TaskService
{
	Map<String, Task> hold = new HashMap<>();
	
	public Task add(String id, String name, String description)
	{
		if(id != null)
		{
			if(id.length() > 10)
			{
				id = id.substring(0, 10);
			}
			if(hold.containsKey(id))
			{
				System.out.println("ID found, returning known value");
			}
			else
			{
				hold.put(id, new Task(id, name, description));
			}
			return hold.get(id);
		}
		else
		{
			return new Task();
		}
	}
	
	public Task delete(String id)
	{
		return hold.remove(id);
	}
	
	public Task updateAll(String id, String name, String description)
	{
		Task temp = hold.get(id);
		temp.SetName(name);
		temp.SetDescription(description);
		return temp;
	}
	public Task updateName(String id, String name)
	{
		Task temp = hold.get(id);
		temp.SetName(name);
		return temp;
	}
	public Task updateDesc(String id, String description)
	{
		
		Task temp = hold.get(id);
		temp.SetDescription(description);
		return temp;
	}

}
