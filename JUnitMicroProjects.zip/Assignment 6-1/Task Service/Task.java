package taskService;

public class Task
{
	private String Iden, Name, Desc;
	
	public Task()
	{
		Iden = Name = Desc = "ERROR";
	}
	
	public Task(String ID, String name, String description)
	{
		if(ID == null)
		{
			Iden = "EMPTY";
		}
		else if (ID.length() > 10)
		{
			Iden = ID.substring(0, 10);
		}
		else
		{
			Iden = ID;
		}
		if(name == null)
		{
			Name = "EMPTY";
		}
		else if (name.length() > 20)
		{
			Name = name.substring(0, 20);
		}
		else
		{
			Name = name;
		}
		if(description == null)
		{
			Desc = "NO DESCRIPTION";
		}
		else if (description.length() > 50)
		{
			Desc = description.substring(0, 50);
		}
		else
		{
			Desc = description;
		}
	}
	
	public String GetID()
	{
		return Iden;
	}
	public String GetName()
	{
		return Name;
	}
	public String GetDescription()
	{
		return Desc;
	}
	
	public void SetName(String name)
	{
		if(name == null)
		{
		}
		else if (name.length() > 20)
		{
			Name = name.substring(0, 20);
		}
		else
		{
			Name = name;
		}
	}
	public void SetDescription(String description)
	{
		if(description == null)
		{
		}
		else if (description.length() > 50)
		{
			Desc = description.substring(0, 50);
		}
		else
		{
			Desc = description;
		}
	}
	
	
	public String toString()
	{
		return Iden + ": " + Name + " " + '\n' + Desc;
	}
}
