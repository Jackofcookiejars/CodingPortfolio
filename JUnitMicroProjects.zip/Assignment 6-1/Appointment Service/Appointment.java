package appointmentService;

import java.util.Date;

public class Appointment
{
	private String iden, desc;
	private Date schd;
	
	public Appointment()
	{
		iden = "error";
		desc = "empty";
		schd = new Date();
	}
	public Appointment(String id, Date day, String description)
	{
		//These if statements ensure that the following are true:
		//No variable input is null
		//id is less than 10 characters
		//description is less than 50 characters
		//the scheduled day is later than current time.
		if(id == null)
		{
			iden = "error";
		}
		else if(id.length() > 10)
		{
			iden = id.substring(0, 10);
		}
		else
		{
			iden = id;
		}
		if(day == null)
		{
			//As Date stores the info as an integer, telling the system that an error
			//has occurred another way is necessary.
			schd = new Date();
			iden = "error";
		}
		else if(day.before(new Date()))
		{
			//As Date stores the info as an integer, telling the system that an error
			//has occurred another way is necessary.
			schd = new Date();
			iden = "error";
		}
		else
		{
			schd = day;
		}
		if(description == null)
		{
			desc = "empty";
		}
		else if(description.length() > 50)
		{
			desc = description.substring(0,50);
		}
		else
		{
			desc = description;
		}
		
	}
	
	public Date getDate()
	{
		return schd;
	}
	public String getDescription()
	{
		return desc;
	}
	public String getID()
	{
		return iden;
	}

	public void setDate(Date time)
	{
		if(time != null)
		{
			if(time.after(new Date()))
			{
				schd = time;
			}	
		}
	}
	public void setDesc(String description)
	{
		if(description != null)
		{
			if (description.length() > 50)
			{
				desc = description.substring(0, 50);
			}
			else
			{
				desc = description;
			}
		}
	}

	public String toString()
	{
		return iden + ": " + schd + " " +
				desc;
	}
}
