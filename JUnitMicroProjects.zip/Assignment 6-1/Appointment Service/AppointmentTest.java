package appointmentService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.Test;

public class AppointmentTest
{
	@Test
	public void testAppointmentConstructors()
	{
		//First we test to see if the default constructor
		//properly fills the fields.
		Appointment test = new Appointment();
		assertTrue(test.getID() != null);
		assertTrue(test.getDate() != null);
		assertTrue(test.getDescription()!= null);
		
		//Now we start testing the inputs.
		test = new Appointment(null,null,null);
		assertTrue(test.getID() != null);
		assertTrue(test.getDate() != null);
		assertTrue(test.getDescription()!= null);
		
		//Here we make sure the string variables are restricted properly.
		test = new Appointment("01234567890", new Date(999999999999999999L), "Oh, how I wish I had to not write out 51 characters");
		assertTrue(test.getID().length() < 11);
		assertTrue(test.getDescription().length() < 51);
		
		//Now we test the Date variable.
		test = new Appointment("", new Date(0), "");
		assertTrue(test.getID() == "error");
		
		//Finally, we test a valid appointment.
		test = new Appointment("John Doe",new Date(999999999999999999L), "Dr. Brian, oral cleaning.");
		assertTrue(test.getID().equals("John Doe"));
		assertTrue(test.getDate().getTime() == 999999999999999999L);
		assertTrue(test.getDescription().equals("Dr. Brian, oral cleaning."));
	}
	
	@Test
	public void testAppointmentSetAndGet()
	{
		Appointment test = new Appointment("John Doe",new Date(999999999999999999L), "Dr. Brian, oral cleaning.");
		//Now we test the setters
		//Test for null sets.
		test.setDate(null);
		assertTrue(test.getDate().equals(new Date(999999999999999999L)));
		test.setDesc(null);
		assertTrue(test.getDescription() == "Dr. Brian, oral cleaning."); 
		
		//Test for invalid sets.
		test.setDate(new Date(0));
		assertTrue(test.getDate().equals(new Date(999999999999999999L)));
		test.setDesc("Oh, how I wish I had to not write out 51 characters");
		assertTrue(!test.getDescription().equals("Oh, how I wish I had to not write out 51 characters"));
		
		//Now we test a new set of valid variables.
		test.setDate(new Date(999999999999999L));
		assertTrue(test.getDate().equals(new Date(999999999999999L)));
		test.setDesc("Valid check");
		assertTrue(test.getDescription().equals("Valid check"));
	}
}
