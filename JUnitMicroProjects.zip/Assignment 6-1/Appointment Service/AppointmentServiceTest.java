package appointmentService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.Test;

public class AppointmentServiceTest
{
	@Test
	public void AppointmentServiceUsabilityTest() 
	{
		//Set up to test current stuffs.
		AppointmentService test = new AppointmentService();
		
		//Test adding Appointment
		assertTrue(test.add("felix", new Date(999999999999999999L), "felix").getID().equals("felix"));
		assertTrue(test.add("borne", new Date(999999999999999999L), "borne").getDate().equals(new Date(999999999999999999L)));
		assertTrue(test.add("turner", new Date(999999999999999999L), "turner").getDescription().equals("turner"));
		
		
		//Test overlapping IDs
		assertTrue(!test.add("felix",new Date(0), null).equals(new Appointment("felix",new Date(0), null)));
		
		//Test delete.
		assertTrue(!test.delete("felix").getID().equals(test.add("felix", new Date(0), "").getID()));

	}
}
