package appointmentService;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService
{
	Map<String, Appointment> hold = new HashMap<>();
	
	public Appointment add(String id, Date date, String description)
	{
		//Ensure ID isn't null, so a null ID doesn't get added to the map.
		if(id != null)
		{
			if(id.length() > 10)
			{
				//length too long, shouldn't overlap too much.
				id = id.substring(0, 10);
			}
			//Ensure unique IDs.
			if(hold.containsKey(id))
			{
				System.out.println("ID found, returning known value");
			}
			else
			{
				hold.put(id, new Appointment(id, date, description));
			}
			return hold.get(id);
		}
		else
		{
			return new Appointment();
		}
	}
	
	public Appointment delete(String id)
	{
		return hold.remove(id);
	}
}
