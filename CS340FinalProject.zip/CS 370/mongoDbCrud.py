from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self):
        #Mongo Client initializer.
        #Accesses databases and Collections.
        #Hardwired to AAC, animals, and the user.
        USER = 'aacuser'
        PASS = 'test'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31519
        DB = 'AAC'
        COL = 'animals'

        #Connect
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        print("Client defined")
        self.database = self.client['%s' % DB]
        print("Database defined")
        self.collection = self.database['%s' % (COL)]
        print("Collection defined")
        
    def __init__(self, user, pWord):
    	#Mongo Client initializer.
        #Accesses databases and Collections.
        #Hardwired to AAC and animals.
        
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31519
        DB = 'AAC'
        COL = 'animals'

        #Connect
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (user,pWord,HOST,PORT))
        print("Client defined")
        self.database = self.client['%s' % DB]
        print("Database defined")
        self.collection = self.database['%s' % (COL)]
        print("Collection defined")
    	

    def create(self, data):
        if data is not None:
            return self.database.animals.insert_one(data).acknowledged
        else:
            raise Exception("Data inserted is empty")
    
    def read(self, data):
        if data is not None:
            return list(self.database.animals.find(data))
        else:
            raise Exception("Data to search is empty")

    def update(self, data, data2):
        if (data is not None) and (data2 is not None):
            return self.database.animals.update_many(data, data2)
            
        else:
            raise Exception("Data or Data2 is empty")

    def delete(self, data):
        if data is not None:
            return self.database.animals.delete_many(data)
        else:
            raise Exception("Data to delete is empty")
