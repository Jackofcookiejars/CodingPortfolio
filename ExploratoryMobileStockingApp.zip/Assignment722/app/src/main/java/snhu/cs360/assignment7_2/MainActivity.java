package snhu.cs360.assignment7_2;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private LoginDatabaseHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            DB = new LoginDatabaseHelper(this);



            return insets;
        });
    }

    public void onCreateClick(View view)
    {
        //Make sure to hide the values so they don't overlap.
        findViewById(R.id.LoginFailedText).setVisibility(View.INVISIBLE);
        findViewById(R.id.CreateFailedText).setVisibility(View.INVISIBLE);

        //Get the two editable fields.
        TextView uNameField = findViewById(R.id.usernameField);
        TextView pWordField = findViewById(R.id.passwordField);

        //Add the UN/P combo.
        if(!DB.addItem(uNameField.getText().toString(), pWordField.getText().toString()))
        {
            //This should only pop up if someone doubles up on usernames.
            findViewById(R.id.CreateFailedText).setVisibility(View.VISIBLE);
        }

        //Empty fields to force them to input the values again.
        uNameField.setText("");
        pWordField.setText("");

    }

    public void onLoginClick(View view)
    {
        //Make sure to hide the values so they don't overlap.
        findViewById(R.id.LoginFailedText).setVisibility(View.INVISIBLE);
        findViewById(R.id.CreateFailedText).setVisibility(View.INVISIBLE);

        //Check to see if user has a valid login
        if (DB.check(((TextView)findViewById(R.id.usernameField)).getText().toString(),
                ((TextView)findViewById(R.id.passwordField)).getText().toString()))
        {
            //User validation complete, entering second screen.
            android.content.Intent intent = new android.content.Intent(this,
                    DatabaseReader.class);
            startActivity(intent);
        }
        else
        {
            //Show error.
            findViewById(R.id.LoginFailedText).setVisibility(View.VISIBLE);
        }

    }
}