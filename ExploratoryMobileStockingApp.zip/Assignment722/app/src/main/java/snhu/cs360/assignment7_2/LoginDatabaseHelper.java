package snhu.cs360.assignment7_2;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class LoginDatabaseHelper extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "assignmentsDB1.dat";
    private static final int VERSION = 1;
    private final SQLiteDatabase DB;

    public LoginDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        DB = getWritableDatabase();
    }

    private static final class assignmentTable
    {
        private static final String TABLE = "entryMap";
        private static final String COL_NAME = "name";
        private static final String COL_PASS = "count";
    }


    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("create table " + assignmentTable.TABLE + " (" +
                assignmentTable.COL_NAME + " text primary key, " +
                assignmentTable.COL_PASS + " text) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("drop table if exists " + assignmentTable.TABLE);
        onCreate(db);
    }

    public boolean addItem(String name, String pass)
    {
        if(nameExists(name))
        {
            return false;
        }
        Log.d(TAG, name + " " + pass);
        ContentValues values = new ContentValues();
        values.put(assignmentTable.COL_NAME, name);
        values.put(assignmentTable.COL_PASS, pass);
        DB.insert(assignmentTable.TABLE, null, values);
        return true;


    }

    private boolean nameExists(String name)
    {
        String sql = "select * from " + assignmentTable.TABLE + " where name = ?";
        Cursor cursor = DB.rawQuery(sql, new String[] {name});
        String temp = null;
        if(cursor.moveToFirst())
        {
            temp = cursor.getString(0);
        }
        cursor.close();
        return temp != null;
    }

    public boolean check(String UName, String PWord)
    {
        String sql = "select * from " + assignmentTable.TABLE + " where name = ?";
        Cursor cursor = DB.rawQuery(sql, new String[] {UName});
        String temp = null;
        if(cursor.moveToFirst())
        {
            temp = cursor.getString(1);
        }
        cursor.close();
        if(temp!=null)
        {
            if(temp.equals(PWord))
            {
                return true;
            }
        }
        return false;

    }
}
