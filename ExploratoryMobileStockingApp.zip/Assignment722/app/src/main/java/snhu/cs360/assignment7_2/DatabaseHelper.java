package snhu.cs360.assignment7_2;

import static android.content.ContentValues.TAG;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "assignmentsDB.dat";
    private static final int VERSION = 1;
    private final SQLiteDatabase DB;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        DB = getWritableDatabase();
    }

    private static final class assignmentTable
    {
        private static final String TABLE = "stock";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_COUNT = "count";
    }


    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("create table " + assignmentTable.TABLE + " (" +
                assignmentTable.COL_ID + " integer primary key autoincrement, " +
                assignmentTable.COL_NAME + " text, " +
                assignmentTable.COL_COUNT + " integer) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("drop table if exists " + assignmentTable.TABLE);
        onCreate(db);
    }

    public long addItem(String name, int count)
    {
        ContentValues values = new ContentValues();
        values.put(assignmentTable.COL_NAME, name);
        values.put(assignmentTable.COL_COUNT, count);

        return DB.insert(assignmentTable.TABLE, null, values);


    }

    public int getSize()
    {
        String sql = "select * from " + assignmentTable.TABLE;
        Cursor cursor = DB.rawQuery(sql, new String[] {});
        int temp = 0;
        if(cursor.moveToFirst())
        {
           temp = cursor.getCount();
        }
        cursor.close();
        return temp;
    }

    public String[] searchDBbyID(String searchable)
    {
        String sql = "select * from stock where _id = ?";
        Cursor cursor = DB.rawQuery(sql, new String[] {searchable});
        if (!cursor.moveToFirst()) {
            cursor.close();
            Log.d(TAG, "No Matching Values Found");
            return new String[]{""};
        } else {
            String[] temp = {"", ""};
            temp[0]=cursor.getString(1);
            temp[1]=cursor.getString(2);
            cursor.close();
            return temp;

        }

    }

    public void dropTable()
    {
        DB.execSQL("drop table if exists " + assignmentTable.TABLE);
        onCreate(DB);
    }

}
