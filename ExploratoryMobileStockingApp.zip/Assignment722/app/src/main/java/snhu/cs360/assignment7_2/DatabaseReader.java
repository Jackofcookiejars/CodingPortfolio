package snhu.cs360.assignment7_2;

import static android.content.ContentValues.TAG;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Objects;

public class DatabaseReader extends AppCompatActivity
{
    private DatabaseHelper DB;
    EditText addEditText;
    TableLayout stockTable;
    private boolean tableObtained = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_database_reader);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            //This sets the important views and fields.
            addEditText = findViewById(R.id.addItemName);

            readData();

            //Generates the add new item button interaction.
            findViewById(R.id.addItem).setOnClickListener(view -> addButtonClick());

            //Creates a pointer to and fills the scrollable table
            stockTable = findViewById(R.id.scrollableTable);
            if(!tableObtained)
            {
                //This should check the database to fill the table.
                for (int a = 0; a < DB.getSize(); a++)
                {
                    String[] temp = DB.searchDBbyID(String.valueOf(a+1));
                    if(!Objects.equals(temp[0], "")){
                        addRow(temp[0], Integer.parseInt(temp[1]));
                    }

                }
                //This ensures that the table search isn't ran more than once.
                tableObtained = true;
            }
            return insets;
        });
    }

    private void addButtonClick()
    {
        //Gets the text from the add new item field.
        String inText = addEditText.getText().toString().trim();

        //Resets add new item field.
        addEditText.setText("");

        //Ships off the information gathered by button click.
        if(!inText.isEmpty())
        {
            addRow(inText,0);
        }
    }

    private void addRow(String inputText, int count)
    {
        //This creates the table row with inText.
        TableRow tr = new TableRow(this);
        //This creates the text view where the stocked item's name is.
        TextView tv = new TextView(this);
        tv.setText(inputText);
        tv.setWidth((int) (150 * (this.getResources().getDisplayMetrics().density) +0.5f ));
        //This creates the editable text view where the stock count is.
        EditText et = new EditText(this);
        et.setText(String.valueOf(count));
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setWidth((int) (90 * (this.getResources().getDisplayMetrics().density) +0.5f ));
        et.setGravity(View.TEXT_ALIGNMENT_CENTER);
        //This checks for changes to trigger the low volume notification.
        //TODO: Convince client to finish this.
        et.addTextChangedListener(new TextWatcher() {
            //These two are here just to fulfil the Abstract.
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2){}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            //This is where I'm trying to get the final value through here.
            @Override
            public void afterTextChanged(Editable editable)
            {
                //Figure out how to read from editable.
                if(editable.toString().equals("0"))
                {
                    //Call the SMS text method.
                    //TODO: Talk with clients to figure out a replacement for this.
                    SmsManager sms = getApplicationContext().getSystemService(SmsManager.class);
                    //Currently hard-coded. Can't be bothered to fetch a number through perms.
                    sms.sendTextMessage("6505551212", null,
                            "A stocked item is low!", null, null);


                }
            }
        });
        //This creates the clickable button that deletes the row
        Button delButton = new Button(this);
        Object tag = tv.getText().toString().trim();
        delButton.setTag(tag);
        delButton.setOnClickListener(view -> {
           View row = (View) view.getParent();
           stockTable.removeView(row);
           stockTable.invalidate();
        });

        //This adds everything to the row, then the row to the table.
        tr.addView(tv);
        tr.addView(et);
        tr.addView(delButton);
        stockTable.addView(tr);
    }

    private void saveData()
    {
        DB.dropTable();
        for(int a = 0; a < stockTable.getChildCount(); a++)
        {
            TableRow row = (TableRow)stockTable.getChildAt(a);
            String temp = ((TextView)row.getChildAt(0)).getText().toString();
            int temp2 = Integer.parseInt (((EditText)row.getChildAt(1)).getText().toString());
            DB.addItem(temp,temp2);
        }

    }

    private void readData()
    {
        DB = new DatabaseHelper(getApplicationContext());
    }



    public void hasPhonePermissions(View view)
    {
        hasPhonePermissions();
    }
    private boolean hasPhonePermissions()
    {
        String phonePermission = "android.permission.SEND_SMS";
        if(ContextCompat.checkSelfPermission(this, phonePermission) != PackageManager.PERMISSION_GRANTED)
        {
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, phonePermission))
            {

            }
            else
            {
                int REQUEST_PHONE_CODE = 0;
                ActivityCompat.requestPermissions(this, new String[] {phonePermission}, REQUEST_PHONE_CODE);
            }
            return false;
        }
        else
        {
            findViewById(R.id.permissionsButton).setEnabled(false);
            findViewById(R.id.permissionsButton).setVisibility(View.INVISIBLE);
        }
        return true;
    }


    @Override
    public void onDestroy() {
        saveData();
        super.onDestroy();
    }
}