// NAME: ABCU Registry Parser
// BY:   Zayne Harthun
// Ver:  1.0
// DESC: Project Two Final Submission


#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

//Global Var. for sanity's sake.
const unsigned int DEFAULT_SIZE = 100;


//Course variable for course work.
struct Course
{
	string courseID;
	string courseName;
	vector<string> coursePrereq;
	Course()
	{
		coursePrereq.resize(0);
	}
};

class HashTable
{
	//Define structure for
	struct Node
	{
		Course course;
		unsigned int hash;
		Node* next;

		Node()
		{
			hash = UINT_MAX;
			next = nullptr;
		}

		Node(Course cIn) : Node()
		{
			course = cIn;
		}

		Node(Course cIn, unsigned int hIn) : Node(cIn)
		{
			hash = hIn;
		}
	};

	vector<Node> buckets;
	
	unsigned int tableSize = DEFAULT_SIZE;
	
	unsigned int hash(string key);

public:
	HashTable();
	HashTable(unsigned int size);
	virtual ~HashTable();
	void Insert(Course course);
	void PrintSearch(string courseID);
	Course* Search(string courseID);
	void DeptSearch(string deptID);
	size_t Size();
};

//Default and size constructors
HashTable::HashTable()
{
	//Resize buckets.
	buckets.resize(this->tableSize);
}
HashTable::HashTable(unsigned int size)
{
	//Set table size.
	this->tableSize = size;
	//Call default constructor.
	buckets.resize(this->tableSize);
}

//Destructor
HashTable::~HashTable()
{
	for (int bucketNum = 0; buckets.size() > bucketNum; bucketNum++)
	{
		//Declare current and temp;
		Node* curr = nullptr;
		Node* temp = nullptr;

		//point at current bucket.
		curr = buckets.at(bucketNum).next;

		//Begin cleansing bucket.
		while (curr != nullptr)
		{
			//Mark node
			temp = curr;
			//Orphan node
			curr = curr->next;
			//Remove orphan.
			delete temp;
		}
	}
}

unsigned int HashTable::hash(string key)
{
	//Create key for given course
	unsigned int hash = 0;

	//For loop to build the HashKey from key.
	//First, generate lower hash values.
	for (int curr = 0; curr < 4; curr++)
	{
		hash += key.at(curr);
	}
	//Now modify the value to make it two digit. aaaa is 260, and zzzz is 360, so subtracting 260 gives 0-100 (inclusive)
	hash -= 260;
	//Taking the modulo here gets 0-99 (inclusive) it's really unlikely to get close to the edges, but it should be fine.
	hash = hash % 100;

	//Now we add the rest of the values, multiplied by 100 to preserve the last 2 digits.
	for (int curr = 4; curr < key.size(); curr++)
	{
		hash += 100 * key.at(curr);
	}

	//Now modulo to get it to fit buckets.
	hash = hash % (buckets.size() - 1);

	//Ship the final product.
	return hash;
}

void HashTable::Insert(Course course)
{
	unsigned int hash = 0;

	//Now we pass courseID to hash to get the hash key.
	hash = this->hash(course.courseID);

	//Check to see if head node is used.
	if (buckets.at(hash).hash == UINT_MAX)
	{
		//It doesn't, so fill head node with these fancy values.
		buckets.at(hash).hash = hash;
		buckets.at(hash).course = course;
	}
	//Since it is, go down the list.
	else
	{
		//Create pointer to head.
		Node* temp = &(buckets.at(hash));
		//Traverse list
		while (temp->next != nullptr)
		{
			temp = temp->next;
		}
		//At the end of the list, create a new node.
		temp->next = new Node(course, hash);
	}
}

Course* HashTable::Search(string courseID)
{
	//Get where we're looking.
	unsigned int hash = this->hash(courseID);

	//Check to see if bucket has values.
	if (buckets.at(hash).hash == UINT_MAX)
	{
		//It doesn't return empty course.
		return nullptr;
	}
	//Bucket has values, start going down bucket.
	else
	{
		//Create pointer to the head
		Node* curr = &(buckets.at(hash));
		while(curr!=nullptr)
		{
			//Check to see if current contains desired course.
			if (curr->course.courseID == courseID)
			{
				//It does, return course.
				return &(curr->course);
			}
			//Increment loop.
			curr = curr->next;
		}
		//At this point, the loop has run its course, either user
		//input a faulty value, or desired ID doesn't exist yet.
		return nullptr;
	}
}

void HashTable::DeptSearch(string deptID)
{
	//Search each bucket with matching last digits to Hash+1.
	//For some reason hashing from deptID always gives 1 less than the hashing from the load.
	for (int bucketCheck = hash(deptID)+1; bucketCheck < tableSize; bucketCheck += 100)
	{
		if (buckets.at(bucketCheck).hash != UINT_MAX)
		{
			Node* curr = &(buckets.at(bucketCheck));
			while (curr != nullptr)
			{
				cout << curr->course.courseID << " " << curr->course.courseName << endl;
				curr = curr->next;
			}
		}
	}
}

size_t HashTable::Size()
{
	return tableSize;
}

void HashTable::PrintSearch(string courseID)
{
	Course* course = Search(courseID);
	if (course == nullptr)
	{
		cout << "Designated course does not exist." << endl;
	}
	else
	{
		cout << course->courseID << " is also known as " << course->courseName << ". It has ";
		cout << course->coursePrereq.size() << " prerequisites";
		if (course->coursePrereq.size() == 1)
		{
			cout << ". It is " << course->coursePrereq.at(0) << ".";
		}
		else if (course->coursePrereq.size() == 0)
		{
			cout << ".";
		}
		else
		{
			cout << ", they are as follow : ";
			for (int prereqCount = 0; prereqCount < course->coursePrereq.size(); prereqCount++)
			{
				cout << course->coursePrereq.at(prereqCount) << " ";
			}
		}
		cout << endl;
	}

}

bool fileSearch(string name)
{
	if (name == "")
	{
		return true;
	}
	bool matches = false;

	//Open file.
	ifstream inFile("CS 300 ABCU_Advising_Program_Input.csv");
	//Check if file successfully opened.
	if (inFile.is_open())
	{
		while (inFile.good() && !matches)
		{
			char courseName[10];
			inFile.getline(courseName, 10, ',');
			inFile.ignore(100, '\n');

			if (strcmp(name.c_str(), courseName) == 0)
			{
				matches = true;
			}
		}
	}
	return matches;
}

void openReg(HashTable* hashTable)
{
	try
	{
		//Open file.
		ifstream inFile("CS 300 ABCU_Advising_Program_Input.csv");
		//Check if file successfully opened.
		if (inFile.is_open())
		{
			//While there's no error.
			while (inFile.good())
			{
				//Create course var
				Course course = Course();
				//Open a character array that can house the entirety of the line.
				char line[100];

				//Get the courseID
				inFile.getline(line, 100, ',');
				//Apply courseID
				course.courseID.append(line);

				//Get the course name
				inFile.getline(line, 100, ',');
				//Apply course name
				course.courseName.append(line);

				if (inFile.peek() == ',')
				{
					inFile.ignore(100, '\n');
					hashTable->Insert(course);
				}
				else
				{
					string newLine = "";
					inFile.getline(line, 100, '\n');
					newLine.append(line);
					course.coursePrereq.push_back(newLine.substr(0, newLine.find(',')));
					newLine = newLine.substr(newLine.find(',') + 1);
					while (newLine.find(',') != string::npos)
					{
						course.coursePrereq.push_back(newLine.substr(0, newLine.find(',')));
						newLine = newLine.substr(newLine.find(',') + 1);
					}
					if (newLine != "")
					{
						course.coursePrereq.push_back(newLine);
					}
					hashTable->Insert(course);
				}
			}
			inFile.close();
		}
	}
	catch (exception& e)
	{
		cout << "Error occurred: " << e.what() << endl;
	}
}

void loadReg(HashTable* hashTable)
{
	try
	{
		//Open file.
		ifstream inFile("CS 300 ABCU_Advising_Program_Input.csv");
		//Check if file successfully opened.
		if (inFile.is_open())
		{
			//While there's no reading error.
			while (inFile.good())
			{
				//Declare char array.
				char line[100];
				
				
				inFile.getline(line, 100);
				
				//Variables needed to error test.
				int count = 0;
				int loc = 0;
				string name = "";
				for (; loc < 99; loc++)
				{
					//Check to see if line ends.
					if (line[loc] == '\0')
					{
						break;
					}
					//Make sure there's enough commas.
					if (line[loc] == ',')
					{
						count++;
					}
					//Start gathering the prerequisite data.
					if (count > 1)
					{
						if (line[loc] == ',')
						{
							//The array hit a comma, check if prerequisite name exists
							if (!fileSearch(name))
							{
								//The class did not exist.
								throw "Prerequisite Failure";
							}

							//Flush name.
							name = "";
						}
						else
						{
							//Since the character isn't a , add it to the prerequisite name.
							name += line[loc];
						}
					}
				}

				//If there's less than 3 commas, and the line wasn't empty
				if (count < 3 && loc > 0)
				{
					throw "Format Mismatch";
				}
			}
			inFile.close();
		}
		//Here we pass the hashTable to load the classes into it.
		openReg(hashTable);
	}
	catch(string e)
	{
		cout << "Error occurred: " << e << endl;
	}
	catch (...)
	{
		cout << "Something unexpected has occurred." << endl;
	}
}

void menu(HashTable* hashTable)
{
	int uInput = 0;
	while (uInput != 9)
	{
		cout << "Menu:" << endl;
		cout << "  1: Load courses" << endl;
		cout << "  2: Print all course from a department" << endl;
		cout << "  3: Print a specific course" << endl;
		cout << "  9: Exit" << endl;
		cout << endl;
		cout << "Please enter your choice:";
		cin >> uInput;
		
		//Two switch cases use this for specification.
		string uStringInput;
		//Switch making.
		switch (uInput)
		{
		case 1:
			loadReg(hashTable);
			break;
		case 2:
			//Get the departmentID from user.
			cout << "Please input the department you are looking for.";
			cin >> uStringInput;
			//Pass the HashTable the departmentID.
			hashTable->DeptSearch(uStringInput);
			//Exit.
			break;
		case 3:
			//Get the courseID from user.
			cout << "Which course are you looking for? ";
			cin >> uStringInput;
			//Pass the HashTable the courseID.
			hashTable->PrintSearch(uStringInput);
			//Exit.
			break;
		case 9:
			//exit
			break;
		default:
			cout << "Please input a valid number." << endl;
			break;
		}
	}
}



int main()
{
	//Store the hashtable
	HashTable* courseReg;
	courseReg = new HashTable(10000);

	menu(courseReg);

	return 0;
}